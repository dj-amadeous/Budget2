package com.example.budget2.ui;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.budget2.R;
import com.example.budget2.model.Expense;
import com.example.budget2.model.Income;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.BarGraphSeries;
import com.jjoe64.graphview.series.DataPoint;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class viewStatsActivity extends AppCompatActivity {
    private ArrayList<Expense> expenseList;
    private ArrayList<Income> incomeList;
    private Button cancelButton;
    private Button demoButton;
    private TextView recurringIncomeText;
    private TextView singleIncomeText;
    private TextView totalIncomeText;
    private TextView wantsText;
    private TextView needsText;
    private TextView totalExpenseText;
    private TextView savesText;
    private TextView lim_dwText;
    private TextView lim_dnText;
    private TextView lim_dsText;
    private TextView lim_mwText;
    private TextView lim_mnText;
    private TextView lim_msText;
    private GraphView graph;
    double singleIncome = 0;
    double totalIncome = 0;
    double passiveIncome = 0;
    double ewantsSum=0;
    double eneedsSum=0;
    double esavesSum=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_stats);

        cancelButton = (Button)findViewById(R.id.cancelButton);
        demoButton = (Button)findViewById(R.id.demoButton);


        //jihuiohiouhiouhiuo

        // make userDumb object with userDumb messages

        //(total monthly income - current expenses        /      30 - days passed) categorized by needs/wants/saves
        //search function
        //display overall income, allowances per category, daily allowance per category

        recurringIncomeText = (TextView) findViewById(R.id.recurringIncome);
        singleIncomeText = (TextView) findViewById(R.id.singleIncome);
        totalIncomeText = (TextView) findViewById(R.id.totalIncome);

        wantsText = (TextView) findViewById(R.id.wants);
        needsText = (TextView) findViewById(R.id.needs);
        totalExpenseText= (TextView) findViewById(R.id.totalExpenses);
        savesText= (TextView) findViewById(R.id.saves);

        lim_dwText= (TextView) findViewById(R.id.lim_dw);
        lim_dnText= (TextView) findViewById(R.id.lim_dn);
        lim_dsText= (TextView) findViewById(R.id.lim_ds);
        lim_mwText= (TextView) findViewById(R.id.lim_mw);
        lim_mnText= (TextView) findViewById(R.id.lim_mn);
        lim_msText= (TextView) findViewById(R.id.lim_ms);


        Intent intent = getIntent();

        Bundle bundle = getIntent().getExtras();

        expenseList = bundle.getParcelableArrayList("expenseList");
        incomeList = bundle.getParcelableArrayList("incomeList");

        //easterEgg();

        makeGraphAndCalculate();
        setTextFields();


        /*FirebaseDatabaseHelper helper = new FirebaseDatabaseHelper();
        helper.ReadExpenses();
        helper.getExpenseList();*/
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        demoButton.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {

                easterEgg();
                makeGraphAndCalculate();
                setTextFields();
            }
        });




    }

    public void makeGraphAndCalculate() {
        ewantsSum=0;
        eneedsSum=0;
        esavesSum=0;

        if(expenseList.size() > 0){
            for (Expense e : expenseList) {
                if (e.getCategory() == 1) // wants
                {
                    ewantsSum += e.getAmount();
                }
                else if (e.getCategory() == 2) // needs
                {
                    eneedsSum += e.getAmount();
                }
                else if (e.getCategory() == 3) // saves
                {
                    esavesSum += e.getAmount();
                }
            }
        }

        if(incomeList.size() > 0){
            for(Income i : incomeList){
                if(i.getCategory()==1){
                    double s = i.getAmount();
                    singleIncome+=s;
                    totalIncome+=s;
                }
                if(i.getCategory()==2){
                    int months = 0;

                    String s = i.getDate();
                    int imonth = 0;
                    if(s.charAt(5)==1) {
                        imonth = 1;
                        if (s.charAt(6) == 0) {
                            imonth = 11;
                        }
                        else if(s.charAt(6)==1){
                            imonth = 12;
                        }
                    }
                    else{
                        imonth = 1 + Character.getNumericValue(s.charAt(5));
                    }


                    java.util.Date date= new Date();
                    Calendar cal = Calendar.getInstance();
                    cal.setTime(date);
                    int cMonth = 1 + cal.get(Calendar.MONTH);

                    if(cMonth > imonth){
                        months = cMonth - imonth;
                    }

                    double p = months * i.getAmount();
                    totalIncome+=p;
                    passiveIncome+=p;
                }
            }
        }

        graph = (GraphView) findViewById(R.id.graph);

        BarGraphSeries<DataPoint> series1 = new BarGraphSeries<>(new DataPoint[]{
                new DataPoint(1, ewantsSum),
                new DataPoint(3, eneedsSum),
                new DataPoint(5, esavesSum),});

        BarGraphSeries<DataPoint> series2 = new BarGraphSeries<>(new DataPoint[]{
                new DataPoint(2, totalIncome * .5),
                new DataPoint(4, totalIncome * .3),
                new DataPoint(6, totalIncome * .2)
        });

        graph.addSeries(series1);
        graph.addSeries(series2);
        series1.setColor(Color.GREEN);
        series1.setSpacing(50);
        series2.setSpacing(50);
    }

    public void setTextFields(){
        recurringIncomeText.setText(Double.toString(passiveIncome));
        singleIncomeText.setText(Double.toString(singleIncome));
        totalIncomeText.setText(Double.toString(totalIncome));

        wantsText.setText(Double.toString(ewantsSum));
        needsText.setText(Double.toString(eneedsSum));
        savesText.setText(Double.toString(esavesSum));
        totalExpenseText.setText(Double.toString(ewantsSum+eneedsSum));

        int daysRemaining = 5; //TODO calculate remaining days in month from date

        double dailyExp = (totalIncome - (ewantsSum+eneedsSum+esavesSum)) / daysRemaining;
        double monthlyExp = (totalIncome - (ewantsSum+eneedsSum+esavesSum));

        lim_dwText.setText(String.format("%.2f", .5 * dailyExp));
        lim_dnText.setText(String.format("%.2f", .3 * dailyExp));
        lim_dsText.setText(String.format("%.2f", .2 * dailyExp));
        lim_mwText.setText(String.format("%.2f", .5 * monthlyExp));
        lim_mnText.setText(String.format("%.2f", .3 * monthlyExp));
        lim_msText.setText(String.format("%.2f", .2 * monthlyExp));
    }



    public void easterEgg(){

        expenseList.add(new Expense(11035, "2019,04,22", 1, "note", "note", 25));
        expenseList.add(new Expense(5004, "2019,04,22", 2, "note", "note", 26));
        expenseList.add(new Expense(6500, "2019,04,22", 3, "note", "note", 27));

        incomeList.add(new Income(255.22, "2019,04,22", 1, "note", 30));
        incomeList.add(new Income(8000, "2019,02,22", 2, "note", 31));

    }
}
